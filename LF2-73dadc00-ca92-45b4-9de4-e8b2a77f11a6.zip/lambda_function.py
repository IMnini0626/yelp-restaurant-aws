import json
import random
import boto3
from opensearchpy import OpenSearch

sqs = boto3.client('sqs')

dynamodb = boto3.resource('dynamodb')
dynamodb_table = dynamodb.Table("yelp-restaurants-2")
ses = boto3.client('ses', region_name="us-east-1")  # 选择你的 AWS 区域


es_host = "https://search-restaurant-pub-aeuqkwlsaajyl3omivwn3qag3u.aos.us-east-1.on.aws"
es_index = "restaurants"
es_type = "Restaurant"  # 你的数据类型
client = OpenSearch(
    hosts=[es_host],
    http_auth=('opensearch', 'Fuck-homework1'),
    use_ssl=True,
    verify_certs=True
)

def get_random_restaurant(cuisine):
    """
    从 OpenSearch 获取 cuisine 类型的一个随机 restaurant_id
    """
    query = {
        "size": 30,
        "query": {
            "match": {
                "Cuisine": cuisine
            }
        }
    }
    
    response = client.search(index=es_index, body=query)
    print(response)
    hits = response["hits"]["hits"]
    
    if not hits:
        return None  # 没找到推荐餐厅
    
    selected_restaurant = random.choice(hits)  # 随机选一个
    restaurant_id = selected_restaurant["_source"]["restaurant_id"]

    print("Find restaurant: " + restaurant_id)
    
    return restaurant_id

def get_restaurant_details(restaurant_id):
    """
    从 DynamoDB 获取完整餐厅信息
    """
    response = dynamodb_table.get_item(Key={"business_id": restaurant_id})
    return response.get("Item")

def format_email_content(restaurant_info):
    """
    格式化餐厅信息为邮件内容
    """
    if not restaurant_info:
        return "Sorry, we couldn't find a restaurant recommendation at this time."
    
    return f"""
    <html>
    <body>
        <h2>🍽️ Restaurant Recommendation for You! 🍽️</h2>
        <p><b>Name:</b> {restaurant_info.get("name", "N/A")}</p>
        <p><b>Address:</b> {restaurant_info.get("address", "N/A")}</p>
        <p><b>Rating:</b> {restaurant_info.get("rating", "N/A")}</p>
        <p><b>Zip Code:</b> {restaurant_info.get("zip_code", "N/A")}</p>
        <p>Enjoy your meal! 🍕🍔🍣</p>
    </body>
    </html>
    """

def send_email(email, subject, content):
    """
    使用 AWS SES 发送电子邮件
    """
    response = ses.send_email(
        Source="yz7596@nyu.edu",  # 你的 SES 认证邮箱
        Destination={"ToAddresses": [email]},
        Message={
            "Subject": {"Data": subject},
            "Body": {
                "Html": {"Data": content}
            }
        }
    )
    return response

def lambda_handler(event, context):
    # print(event)
    for record in event["Records"]:
        message_body = json.loads(record["body"])
        email = message_body.get("email")
        cuisine = message_body.get("cuisine")

        restaurant_id = get_random_restaurant(cuisine)
        restaurant_info = get_restaurant_details(restaurant_id)

        email_content = format_email_content(restaurant_info)

        # 发送邮件
        if email:
            send_email(email, f"Your {cuisine} Restaurant Recommendation", email_content)


    return{
        'statusCode': 200,
        'body': json.dumps(f'Recommendation fetched: {restaurant_info} and sent to email {email}')
    }

