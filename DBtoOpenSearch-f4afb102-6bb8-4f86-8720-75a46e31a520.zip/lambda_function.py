import json
import boto3
from opensearchpy import OpenSearch, helpers

# 连接 DynamoDB
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table("yelp-restaurants-2")

# 连接 OpenSearch
es_host = "https://search-restaurant-pub-aeuqkwlsaajyl3omivwn3qag3u.aos.us-east-1.on.aws"
client = OpenSearch(
    hosts=[es_host],
    http_auth=('opensearch', 'Fuck-homework1'),
    use_ssl=True,
    verify_certs=True
)

es_index = "restaurants"

def sync_dynamodb_to_opensearch():
    """
    从 DynamoDB 读取所有数据，并同步 RestaurantID 和 Cuisine 到 OpenSearch
    """
    try:
        response = table.scan()
        items = response.get("Items", [])

        actions = []
        for item in items:
            if "business_id" in item and "Cuisine" in item:
                action = {
                    "_index": es_index,
                    "_id": item["business_id"],  # 用 business_id 作为唯一 ID
                    "_source": {
                        "restaurant_id": item["business_id"],
                        "Cuisine": item["Cuisine"]
                    }
                }
                actions.append(action)

        if actions:
            helpers.bulk(client, actions)
            print(f"Inserted {len(actions)} items into OpenSearch.")
        else:
            print("No data found in DynamoDB.")

    except Exception as e:
        print(f"Error syncing data: {str(e)}")

def lambda_handler(event, context):
    """
    AWS Lambda 入口函数，调用 sync_dynamodb_to_opensearch() 进行数据同步
    """
    print("Starting sync from DynamoDB to OpenSearch...")
    sync_dynamodb_to_opensearch()
    print("Sync completed.")

    return {
        "statusCode": 200,
        "body": json.dumps("Bruh")
    }
