import json
import boto3

sqs = boto3.client('sqs')
SQS_QUEUE_URL = 'https://sqs.us-east-1.amazonaws.com/440744254746/Q1'

def lambda_handler(event, context):
    # return handle_dining_suggestions(event)

    print(event)
    intent_name = event['interpretations'][0]['intent']['name']
    
    # Handling GreetingIntent
    if intent_name == "GreetingIntent":
        return close_response("Hi there, how can I help?")

    # Handling ThankYouIntent
    elif intent_name == "ThankYouIntent":
        return close_response("You're welcome! Have a great day!")

    # Handling DiningSuggestionsIntent
    elif intent_name == "DiningSuggestionsIntent":
        return handle_dining_suggestions(event)

    # If an unknown intent is encountered
    return close_response(f"Sorry, I cannot understand you.")

# Function to handle DiningSuggestionsIntent
def handle_dining_suggestions(event):
    slots = event['interpretations'][0]['intent']['slots']
    required_slots = ["Location", "Cuisine", "DiningTime", "NumberOfPeople", "Email"]
    
    # Check for missing slots
    for slot in required_slots:
        if slots.get(slot) is None:
            return elicit_slot(event, slot, f"Could you please provide the {slot.lower()}?")

    message_body = {
        "Location": slots["Location"],
        "Cuisine": slots["Cuisine"],
        "DiningTime": slots["DiningTime"],
        "NumberOfPeople": slots["NumberOfPeople"],
        "Email": slots["Email"]
    }

    try:
        # Send message to SQS Queue
        response = sqs.send_message(
            QueueUrl=SQS_QUEUE_URL,
            MessageBody=json.dumps(message_body)
        )

        return close_response(f"Your dining request has been submitted. A confirmation will be sent to {slots['Email']}.")

    except Exception as e:
        return close_response(f"An error occurred while processing your request: {str(e)}")

# Function to prompt user for missing slot
def elicit_slot(event, slot, message):
    return {
        "sessionAttributes": event.get("sessionAttributes", {}),
        "dialogAction": {
            "type": "ElicitSlot",
            "intentName": event['interpretations'][0]['intent']["name"],
            "slots": event['interpretations'][0]['intent']["slots"],
            "slotToElicit": slot,
            "message": {"contentType": "PlainText", "content": message}
        }
    }

# Function to return a final response
def close_response(message):
    # response = {
    #     "fulfillmentState": "Fulfilled",
    #     "messages": [
    #         {
    #             "content": str(message), 
    #             # "unstructured": {
    #             #     "id": str(user_id), 
    #             #     "text": str(message), 
    #             #     "timestamp": str(time)
    #             # }
    #         }
    #     ]
    # }
    # return response
    return {
        "dialogAction": {
            "type": "Close",
            "fulfillmentState": "Fulfilled",
            "message": {"contentType": "PlainText", "content": message}
        }
    }
