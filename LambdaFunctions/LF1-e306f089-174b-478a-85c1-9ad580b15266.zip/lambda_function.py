import json
import boto3

sqs = boto3.client('sqs')
SQS_QUEUE_URL = 'https://sqs.us-east-1.amazonaws.com/440744254746/Q1'

def lambda_handler(event, context):
    print(event)
    intent_name = event['interpretations'][0]['intent']['name']
    
    # Handling GreetingIntent
    if intent_name == "GreetingIntent":
        return close_response("Hi there, how can I help?", event)

    # Handling ThankYouIntent
    elif intent_name == "ThankYouIntent":
        return close_response("You're welcome! Have a great day!", event)

    # Handling DiningSuggestionsIntent
    elif intent_name == "DiningSuggestionsIntent":
        return handle_dining_suggestions(event)

    # If an unknown intent is encountered
    return close_response(f"Sorry, I cannot understand you.", event)

# Function to handle DiningSuggestionsIntent
def handle_dining_suggestions(event):
    slots = event['interpretations'][0]['intent']['slots']
    required_slots = ["Location", "Cuisine", "DiningTime", "NumPeople", "Email"]
    
    # Check for missing slots
    for slot in required_slots:
        if slots.get(slot) is None:
            return elicit_slot(event, slot, f"Could you please provide the {slot.lower()}?")

    message_body = {
        "Location": slots["Location"]["value"]["originalValue"],
        "Cuisine": slots["Cuisine"]["value"]["originalValue"],
        "DiningTime": slots["DiningTime"]["value"]["originalValue"],
        "NumPeople": slots["NumPeople"]["value"]["originalValue"],
        "Email": slots["Email"]["value"]["originalValue"]
    }

    try:
        # Send message to SQS Queue
        response = sqs.send_message(
            QueueUrl=SQS_QUEUE_URL,
            MessageBody=json.dumps(message_body)
        )

        return close_response(f"Your dining request has been submitted. A confirmation will be sent to {slots['Email']['value']['originalValue']}.", event)

    except Exception as e:
        return close_response(f"An error occurred while processing your request: {str(e)}", event)

# Function to prompt user for missing slot
def elicit_slot(event, slot, message):
    slots = event['interpretations'][0]['intent']["slots"]

    # Ensure the missing slot is included in the response
    return {
        "sessionState": {
            "sessionAttributes": event.get("sessionAttributes", {}),
            "intent": {
                "name": event['interpretations'][0]['intent']["name"],
                "slots": {
                    key: value for key, value in slots.items()  # Copy current slots
                }
            },
            "dialogAction": {
                "type": "ElicitSlot",
                "slotToElicit": slot
            }
        },
        "messages": [
            {
                "contentType": "PlainText",
                "content": message
            }
        ],
        "requestAttributes": event.get("requestAttributes", {})
    }

# Function to return a final response
def close_response(message, event=None):
    return {
        "sessionState": {
            "sessionAttributes": event.get("sessionAttributes", {}) if event else {},
            "intent": {
                "name": event['interpretations'][0]['intent']["name"] if event else "DiningSuggestionsIntent",  # Default if no event
                "slots": event['interpretations'][0]['intent']["slots"] if event else {}  # Default if no event
                "state": "Fulfilled"
            },
            # "intentState": {  # This section is critical
            #     "status": "Fulfilled",  # Intent status (fulfilled, failed, etc.)
            #     "confirmationStatus": "Confirmed"  # Confirmation status (confirmed, denied, etc.)
            # },
            "dialogAction": {
                "type": "Close",
                "fulfillmentState": "Fulfilled",
                
            }
        },
        "messages": [
            {
                "contentType": "PlainText",
                "content": message
            }
        ],
        "requestAttributes": event.get("requestAttributes", {}) if event else {}
    }

