import json
import requests
import boto3
import time
import random
from datetime import datetime
from decimal import Decimal

# Yelp API Key
API_KEY = "bvjSKYB1MmJ74SLePDlxPYOUcflIbdPaZwV36-Dof4oT52WlvX8mKSzMo6FuK98AwkRg7uvKigEjbgIgUxVpKlRsjNijyVRHueKEP1oCj7PrZLTpS3Nx5E-e-P2_Z3Yx"

# Yelp API 请求头
HEADERS = {
    "Authorization": f"Bearer {API_KEY}"
}

# 定义不同的餐馆类型
# CUISINES = ["chinese", "italian", "japanese", "mexican", "american"]
CUISINES = ["mexican", "american"]
SORT_OPTIONS = ["best_match", "rating", "review_count", "distance"]
SEARCH_TERMS = ["restaurant", "food", "bar", "cafe", "dining", "lunch"]



START_OFFSET = 0

# 初始化 DynamoDB 资源
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("yelp-restaurants-2")

# def fetch_restaurants(cuisine, total=200):
def fetch_restaurants(cuisine, total=200): # For test, try 50 at one time
    """
    从 Yelp API 获取特定菜系的餐厅信息。
    """
    sort_by = random.choice(SORT_OPTIONS)
    search_term = random.choice(SEARCH_TERMS)
    print(f"Using sort_by: {sort_by}, search_term: {search_term}")
    restaurants = []
    for offset in range(START_OFFSET, START_OFFSET + total, 20):  # Yelp API 每次最多返回 50 条
        
        url = "https://api.yelp.com/v3/businesses/search"
        params = {
            "location": "Manhattan, NY",
            "term": search_term,
            "categories": cuisine,
            "limit": 50,
            "offset": offset,
            "sort_by": sort_by
        }
        response = requests.get(url, headers=HEADERS, params=params)
        if response.status_code == 200:
            data = response.json()
            restaurants.extend(data.get("businesses", []))
            # time.sleep(random.uniform(1, 2))  # 避免 API 速率限制
        else:
            print(f"Error fetching {cuisine} at offset {offset}: {response.json()}")
            break
    return restaurants

def convert_float_to_decimal(value):
    """
    将 float 类型转换为 Decimal 以适配 DynamoDB 存储
    """
    if isinstance(value, float):
        return Decimal(str(value))  # 先转换为字符串再转为 Decimal，避免精度问题
    return value

def store_in_dynamodb(restaurants, cuisine):
    """
    将餐厅信息存储到 DynamoDB 中
    """
    for r in restaurants:
        try:
            item = {
                "business_id": r["id"],
                "name": r["name"],
                "address": ", ".join(r["location"]["display_address"]),
                "coordinates": f"{convert_float_to_decimal(r['coordinates']['latitude'])},{convert_float_to_decimal(r['coordinates']['longitude'])}",
                "review_count": int(r.get("review_count", 0)),
                "rating": convert_float_to_decimal(r.get("rating", 0)),
                "zip_code": r["location"].get("zip_code", ""),
                "insertedAtTimestamp": datetime.utcnow().isoformat(),
                "Cuisine": cuisine
            }
            table.put_item(Item=item)
        except Exception as e:
            print(f"Error inserting {r['name']}: {str(e)}")

def lambda_handler(event, context):
    all_restaurants = []
    for cuisine in CUISINES:
        print(f"Fetching {cuisine} restaurants...")
        data = fetch_restaurants(cuisine)
        all_restaurants.extend(data)
        print(f"Fetched {len(data)} {cuisine} restaurants.")

        print(f"Sleeping for 20 seconds to avoid Yelp API rate limits...")
        time.sleep(30)
    
    # 去重
    unique_restaurants = {r["id"]: r for r in all_restaurants}.values()
    print(f"Total unique restaurants: {len(unique_restaurants)}")
    
    # 存储到 DynamoDB
    for cuisine in CUISINES:
        store_in_dynamodb(unique_restaurants, cuisine)
    
    return {
        "statusCode": 200,
        "body": json.dumps(f"Stored {len(unique_restaurants)} restaurants in DynamoDB")
    }
